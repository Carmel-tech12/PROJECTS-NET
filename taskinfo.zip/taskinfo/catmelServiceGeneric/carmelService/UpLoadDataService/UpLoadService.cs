﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;

namespace UpLoadDataService
{
    public partial class UpLoadDataService : ServiceBase
    {
        public static int numService =0;
        bool degelStart = false, degel = false;
        string hour = "", minute = "";
        System.Timers.Timer runCommands_timer = new System.Timers.Timer();
        Engine _hashEngine;
        public UpLoadDataService()
        {
            InitializeComponent();
        }

        static void ActualMain(String[] args) {
            //   System.Diagnostics.Debugger.Launch();
            //EventLog eventLog = new EventLog();
            //eventLog.Source = "NewSource";
            //eventLog.WriteEntry("in main", EventLogEntryType.Warning, 1001);
            File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "in main" + Environment.NewLine);
            System.ServiceProcess.ServiceBase[] ServicesToRun;
            ServicesToRun = new System.ServiceProcess.ServiceBase[] { new UpLoadDataService() };
            System.ServiceProcess.ServiceBase.Run(ServicesToRun);
        }


        // The main entry point for the process
        static void Main(String[] args)
        {
            if (false)
            {
                UpLoadDataService service1 = new UpLoadDataService();
                service1.TestStartupAndStop( args);
            }
            else
            {
                ActualMain(args);
            }

        }

        protected override void OnStart(string[] args)
        {            
            try
            {
                //System.Diagnostics.Debugger.Launch();
                hour = ConfigurationManager.AppSettings["Hour"].ToString();
                minute = ConfigurationManager.AppSettings["Minute"].ToString();
                File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "hour and minute:" + hour + minute + Environment.NewLine);
            }
            catch
            {
                hour = "4";
                minute = "0";
                File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "in catch hour and minute" + Environment.NewLine);
            }
            degelStart = true;
            degel = true;
            //System.Diagnostics.Debugger.Launch();   
            //EventLog eventLog = new EventLog();
            //eventLog.Source = "NewSource";
            //eventLog.WriteEntry("before hashEngine", EventLogEntryType.Warning, 1001);
            File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "before new engine" + Environment.NewLine);
            _hashEngine = new Engine();
            File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "after new engine" + Environment.NewLine);
            //eventLog.Source = "NewSource";
            //eventLog.WriteEntry("after hashEngine", EventLogEntryType.Warning, 1001);
            runCommands_timer.Interval = 1000 * 60;
            runCommands_timer.AutoReset = true;
            runCommands_timer.Elapsed += new System.Timers.ElapsedEventHandler(RunCommands_timer_Elapsed);
            runCommands_timer.Start();
            RunCommands_timer_Elapsed(null, null);        
        }

        protected override void OnStop()
        {
        }


        internal void TestStartupAndStop(string[] args)
        {
            this.OnStart(args);
            Console.ReadLine();
            this.OnStop();
        }


        void RunCommands_timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            //EventManager.WriteEventInfoMessage("elapsed now");
            if (degelStart == true)//this if is true only one time (after do start to service)
            {
                if (degel == true)
                {
                    runCommands_timer.Interval = 5000;
                    degel = false;
                }
                else
                {
                    runCommands_timer.Stop();
                    //Sets the timer to start working when it reaches real time according to time in app.config
                    //EventManager.WriteEventInfoMessage("start while");
                    //EventLog eventLog =new EventLog();
                    //eventLog.Source ="NewSource";
                    //eventLog.WriteEntry("before While", EventLogEntryType.Warning, 1001);
                    File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "before while" + Environment.NewLine);
                    while ((DateTime.Now.Hour.ToString() != hour|| DateTime.Now.Minute.ToString() != minute)) { }
                    File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "after while" + Environment.NewLine);
                    //EventLog eventLog = new EventLog();
                    //eventLog.Source = "NewSource";
                    //eventLog.WriteEntry("after while", EventLogEntryType.Warning, 1001);
                    //EventManager.WriteEventInfoMessage("finish while");
                    degelStart = false;
                    runCommands_timer.Interval = 1000 * 60 ;
                    runCommands_timer.Start();
                    RunCommands_timer_Elapsed(null, null);

                }
            }
            else
            {
                numService++;
                ReadAllProcedures();
                ReadAllQueries();
            }            
        }

        void ReadAllProcedures()
        {
            //EventManager.WriteEventInfoMessage("start read all procerures");
            _hashEngine.LoadDataOfProcedurs();
            //EventManager.WriteEventInfoMessage("finish read all procerures");
        }

        void ReadAllQueries()
        {
            //EventManager.WriteEventInfoMessage("start read all queries");
            _hashEngine.LoadDataOfQueries();
            //EventManager.WriteEventInfoMessage("finish read all queries");
        }

    }
}
