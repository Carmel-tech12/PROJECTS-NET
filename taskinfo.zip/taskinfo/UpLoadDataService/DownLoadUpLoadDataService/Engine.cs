﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Net;
using System.Xml;
using System.Diagnostics;
using System.Configuration;
using System.IO.Compression;
using System.Drawing;


using System.Text.RegularExpressions;
using Microsoft.VisualBasic.FileIO;
using System.Data.SqlClient;

namespace DownLoadUpLoadDataService
{
    class Engine
    {

        private HttpWebRequest request;
        private CookieContainer cookieContainer = new CookieContainer();
        private static string m_ConnectionString = string.Empty;
        public static string m_folderpath = string.Empty;
        public static string m_user = string.Empty;
        public static string m_pass = string.Empty;
        public static string m_url = string.Empty;
        public static string csv_file_path = string.Empty;
        public static string m_folderpathforzip = string.Empty;
        public static string m_userforzip = string.Empty;
        public static string m_passforzip = string.Empty;
        public static string m_urlxml = string.Empty;
        public static string m_zipPath = string.Empty;
        String email = null;
        String password = null;
        XmlDocument doc = new XmlDocument();

        public Engine()
        {
            LoadGlobalParameters();
        }

        private void LoadGlobalParameters()
        {
            try
            {
                // doc.Load("Config.xml");
                // doc.Load(@"C:\Program Files\UpLoadDataService\UpLoadDataService\bin\Debug\Config.xml");

                doc.Load(@"" + ConfigurationManager.AppSettings["pathXml"]);
            }
            catch (Exception ex)
            {
                //EventManager.WriteEventErrorMessage("can not load the doc", ex);
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "can not load the doc" + Environment.NewLine);
            }

            m_ConnectionString = doc.SelectSingleNode(@"Parameters/ConenctionString").InnerText + "&quot;";
            m_user = doc.SelectSingleNode(@"Parameters/Name").InnerText;
            m_pass = doc.SelectSingleNode(@"Parameters/Pass").InnerText;
            m_url = doc.SelectSingleNode(@"Parameters/Url").InnerText;
            m_zipPath = doc.SelectSingleNode(@"Parameters/folderpathforzip").InnerText;
            m_userforzip = doc.SelectSingleNode(@"Parameters/Nameforzip").InnerText;
            m_passforzip = doc.SelectSingleNode(@"Parameters/Passforzip").InnerText;
            m_urlxml = doc.SelectSingleNode(@"Parameters/UrlXml").InnerText;
            m_folderpath = doc.SelectSingleNode(@"Parameters/folderpath").InnerText;
            m_folderpathforzip = doc.SelectSingleNode(@"Parameters/folderpathforzip").InnerText;
            ConnectionManager.ConnectionString = m_ConnectionString;
            ConnectionManager.Provider = doc.SelectSingleNode(@"Parameters/Provider").InnerText;
            csv_file_path = ConfigurationManager.AppSettings["pathofcsvfile"].ToString();
        }
        public static bool degel = true;
        public void InsertIntoSp()
        {
            //EventManager.WriteEventInfoMessage("start ReadXml");
            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "start ReadXml" + Environment.NewLine);
            // DataTable tblML = ConvertToDataTableML(csv_file_path, 25);
            //DataTable tblML = ReadXmlForCA_RequestDetails();
            DataTable tblML = ReadXmlForTasks();
            // EventManager.WriteEventInfoMessage("finish ConvertToDataTable ML from TxtFile");

            //EventManager.WriteEventInfoMessage("start insert the data to tblTaskActivity from xml");
            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "start insert the data to tblTaskActivity from xml" + Environment.NewLine);
            AddIntotblTaskActivity(tblML);
            //AddIntoPsRequestDetails(tblML)
            //EventManager.WriteEventInfoMessage("finish insert the data to tblTaskActivity from xml");
            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "finish insert the data to tblTaskActivity from xml" + Environment.NewLine);

            //need to open zip file here and extract
            //zipFiles("");

        }
        public static DataTable ReadXmlForTasks()

        {
            //EventLog eventLog = new EventLog();

            //eventLog.Source = "NewSource";
            //eventLog.WriteEntry("in ReadXMLFORtask", EventLogEntryType.Warning, 1001);
            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "in ReadXMLFORtask" + Environment.NewLine);
            //string url = @"https://chaina-motorsltd.dira2.co.il/chainamotors/systems/integrationFile.xml";
            string url = @"https://new-trackts.dira2.co.il/taskinfo/systems/integrationData.xml";
            //string get = p1.getData(m_userforzip, m_passforzip, url);
            Engine e = new Engine();
            //EventManager.WriteEventInfoMessage("try to do login");
            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "try to do login" + Environment.NewLine);
            string get = e.getData(m_userforzip, m_passforzip, url);
            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "finish to do login" + Environment.NewLine);
            //EventManager.WriteEventInfoMessage("finish to do login");

            //EventManager.WriteEventInfoMessage("start to loadxml");
            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "start to loadxml" + Environment.NewLine);
            XmlDocument xmlDoc = new XmlDocument();
            //xmlDoc.LoadXml(get);
            try
            {
                //xmlDoc.Load(@"C:\Users\Doctor\Desktop\noLine.xml");
                //xmlDoc.Load(@"C:\Users\Doctor\Desktop\integrationFile.xml");
                //xmlDoc.Load(@"C:\Users\Doctor\Desktop\2LINES.xml");
                xmlDoc.LoadXml(get);
                //xmlDoc.Load(@"C:\HashConnector\checkTask.xml");
                File.WriteAllText(@"C:\HashConnector\carmelService\xmlFromUrl.xml", xmlDoc.InnerXml);
            }
            catch (Exception exs)
            {
                //EventManager.WriteEventErrorMessage("failed to loadxml", exs);
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "failed to loadxml" + Environment.NewLine);

            }

            XmlNodeList nodeList = xmlDoc.SelectNodes("//task");
            string TaskID = "", CreateTime = "", CreatorName = "", CreatorID = "", ActivityTime = "", TaskStatusID = "";
      
            //for each task - status
            DataTable dt = new DataTable();
            for (int col = 0; col < 6; col++)
                dt.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));

            DataRow dr, drAttach, drComment;

            //for commentes
            DataTable dtComment = new DataTable();
            for (int col = 0; col < 7; col++)
                dtComment.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));
            //for attachment
            DataTable dtAttach = new DataTable();
            for (int col = 0; col < 11; col++)
                dtAttach.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));

            //TaskID = node.SelectSingleNode("TaskID").InnerText;
            foreach (XmlNode node in nodeList)
            {
                dr = dt.NewRow();
                TaskID = node.SelectSingleNode("TaskID").InnerText;
                XmlNodeList nodeListline = node.SelectNodes("comments"); //  can also use XPath here
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "in comments" + Environment.NewLine);

                foreach (XmlNode nodeline in nodeListline)
                {
                    XmlNodeList nodeListline2 = nodeline.SelectNodes("comment");
                    File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "in comment" + Environment.NewLine);
                    foreach (XmlNode nodeli in nodeListline2)
                    {

                        // string idreq = "", product_id = "", quantity = "", prodname = "", issue_type = "", status = "", item_key = "";
                        string MyTaskID = "", MyCreateTime = "", MyActivityDesc = "", MyCreatorName = "", MyCreatorID = "", MyActivityTime = "", Comment_ID ="";
                        MyTaskID = TaskID;
                        //MyTaskID = nodeli.SelectSingleNode("MyTaskID").InnerText;
                        MyCreateTime = nodeli.SelectSingleNode("MyCreateTime").InnerText;
                        MyActivityDesc = nodeli.SelectSingleNode("MyActivityDesc").InnerText;
                        MyCreatorName = nodeli.SelectSingleNode("MyCreatorName").InnerText;
                        MyCreatorID = nodeli.SelectSingleNode("MyCreatorID").InnerText;
                        MyActivityTime = nodeli.SelectSingleNode("MyActivityTime").InnerText;
                        Comment_ID = nodeli.SelectSingleNode("Comment_ID").InnerText;

                        File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after read comment from xml" + Environment.NewLine);
                        drComment = dtComment.NewRow();
                        File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after create comments table" + Environment.NewLine);
                        //הכנסת נתונים לטבלה
                        drComment[0] = MyTaskID;
                        drComment[1] = MyCreateTime;
                        drComment[2] = MyActivityDesc;
                        drComment[3] = MyCreatorName;
                        drComment[4] = MyCreatorID;
                        drComment[5] = MyActivityTime;
                        drComment[6] = Comment_ID;
                        dtComment.Rows.Add(drComment);
                        File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after adddddd comments table" + Environment.NewLine);
                    }
                }

                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after read comments" + Environment.NewLine);

                XmlNodeList nodeListAttach = node.SelectNodes("attachments"); //  can also use XPath here
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "in attachments" + Environment.NewLine);

                foreach (XmlNode nodeline in nodeListAttach)
                {
                    XmlNodeList nodeListline2 = nodeline.SelectNodes("attachment");
                    foreach (XmlNode nodeli in nodeListline2)
                    {
                        string ItemID = "", AttachName = "", AttachDescription = "", AttachTime = "", AttachSize = "", MyCreatorName = "", ContentType = "", AttachData = "", UserID = "" , ItemTypeID = "1" , Attachment_ID ="";
                        ItemID = nodeli.SelectSingleNode("MyTaskID").InnerText;
                        AttachName = nodeli.SelectSingleNode("AttachName").InnerText;
                        AttachDescription = nodeli.SelectSingleNode("AttachDescription").InnerText;
                        AttachTime = nodeli.SelectSingleNode("AttachTime").InnerText;
                        AttachSize = nodeli.SelectSingleNode("AttachSize").InnerText;
                        MyCreatorName = nodeli.SelectSingleNode("CreatorName").InnerText;
                        ContentType = nodeli.SelectSingleNode("ContentType").InnerText;
                        AttachData = nodeli.SelectSingleNode("AttachData").InnerText;
                        UserID = nodeli.SelectSingleNode("UserID").InnerText;
                        Attachment_ID = nodeli.SelectSingleNode("Attachment_ID").InnerText;
                        drAttach = dtAttach.NewRow();
                        //הכנסת נתונים לטבלה
                        drAttach[0] = ItemID;
                        drAttach[1] = AttachName;
                        drAttach[2] = AttachDescription;
                        drAttach[3] = AttachTime;
                        drAttach[4] = AttachSize;
                        drAttach[5] = MyCreatorName;
                        drAttach[6] = ContentType;
                        drAttach[7] = AttachData;
                        drAttach[8] = UserID;
                        drAttach[9] = ItemTypeID;
                        drAttach[10] = Attachment_ID;
                        dtAttach.Rows.Add(drAttach);
                        File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "done read attch elements" + Environment.NewLine);
                    }
                }

                //TaskID = node.SelectSingleNode("TaskID").InnerText;
                CreateTime = node.SelectSingleNode("CreateTime").InnerText;
                CreatorName = node.SelectSingleNode("CreatorName").InnerText;
                CreatorID = node.SelectSingleNode("CreatorID").InnerText;
                ActivityTime = node.SelectSingleNode("ActivityTime").InnerText;
                TaskStatusID = node.SelectSingleNode("TaskStatusID").InnerText;

                dr[0] = TaskID;
                dr[1] = CreateTime;
                //dr[2] = MyActivityDesc;
                dr[2] = CreatorName;
                dr[3] = CreatorID;
                dr[4] = ActivityTime;
                dr[5] = TaskStatusID;

                dt.Rows.Add(dr);
            }
            //EventLog eventLog = new EventLog();

            //eventLog.Source = "NewSource";
            //eventLog.WriteEntry("beforeRequestLineDetails", EventLogEntryType.Warning, 1001);
            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "before AddIntotblTaskActivity" + Environment.NewLine);
            //CA_RequestLineDetailsPs(dtLine);
            //InsertToFiles(dtLine);
            insertComments(dtComment);
            insertAttachments(dtAttach);

            return dt;
        }

        public static void insertCommentsPS(DataTable dt)
        {
            int count = dt.Rows.Count, mone = 0;
            string connectionString = m_ConnectionString;
            // https://stackoverflow.com/questions/9648934/insert-into-if-not-exists-sql-server

            string insertQuery = "INSERT INTO tblTaskActivity (TaskID,CreateTime,ActivityDescription, CreatorName, CreatorID, ActivityTime) VALUES (@MyTaskID, @MyCreateTime, @MyActivityDesc, @MyCreatorName, @MyCreatorID, @MyActivityTime) \n\r";

            using (SqlConnection connection = new SqlConnection(connectionString))
                while (count > 0 && count > 3)
                {
                    DataRow row = dt.Rows[mone];
                    //CA_LogPs(dt, mone);

                    count = count - 3;
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // define your parameters ONCE outside the loop, and use EXPLICIT typing
                        command.Parameters.Add("@MyTaskID", SqlDbType.Int);
                        command.Parameters.Add("@MyCreateTime", SqlDbType.DateTime);
                        command.Parameters.Add("@MyActivityDesc", SqlDbType.NVarChar);
                        command.Parameters.Add("@MyCreatorName", SqlDbType.NVarChar);
                        command.Parameters.Add("@MyCreatorID", SqlDbType.Int);
                        command.Parameters.Add("@MyActivityTime", SqlDbType.DateTime);                 
                        connection.Open();
                        //     for (int t = 0; t < row.ItemArray.Count()-2; t++)

                        for (int t = mone; t < (mone + 3); t++)
                        {
                            //  SET the values
                            try
                            {
                                command.Parameters["@MyTaskID"].Value = int.Parse((dt.Rows[t][0]).ToString());
                                command.Parameters["@MyCreatorID"].Value = int.Parse((dt.Rows[t][4]).ToString());
                            }
                            catch //if ReqNo or LineId are empty do not insert the line
                            {
                                continue;
                            }
                            command.Parameters["@MyCreatorName"].Value = (dt.Rows[t][3]).ToString();
                            command.Parameters["@MyCreateTime"].Value = DateTime.Parse((dt.Rows[t][1]).ToString());
                            command.Parameters["@MyActivityTime"].Value = DateTime.Parse((dt.Rows[t][5]).ToString());
                            command.Parameters["@MyActivityDesc"].Value = (dt.Rows[t][4]).ToString();
                            /*try
                            {
                                command.Parameters["@BillTo"].Value = int.Parse((dt.Rows[t][6]).ToString());
                            }
                            catch
                            {
                                command.Parameters["@BillTo"].Value = 0;
                            }*/
                            command.ExecuteNonQuery();
                        }
                        connection.Close();
                    }
                    mone = mone + 3;
                }
            //if (count > 0)
                //יש פחות שורות מ3 ולכן ישלחו אחת אחרי השניה

                //AddIntoPsComments(dt, count);
        }



        public static void insertAttachmentsPS(DataTable dt)
        {
            int count = dt.Rows.Count, mone = 0;
            string connectionString = m_ConnectionString;
            // https://stackoverflow.com/questions/9648934/insert-into-if-not-exists-sql-server
            string insertQuery = "insert into tblAttach(AttachName, AttachDescription, AttachTime, AttachSize, ItemTypeID, ItemID, UserID, AttachData, CreatorName, ContentType) VALUES(@AttachName, @AttachDescription, @AttachTime, @AttachSize, @ItemTypeID, @ItemID, @UserID, @AttachData, @CreatorName, @ContentType) \n\r";

            using (SqlConnection connection = new SqlConnection(connectionString))
                while (count > 0 && count > 3)
                {
                    DataRow row = dt.Rows[mone];
                    //CA_LogPs(dt, mone);

                    count = count - 3;
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // define your parameters ONCE outside the loop, and use EXPLICIT typing
                        command.Parameters.Add("@AttachName", SqlDbType.NVarChar);
                        command.Parameters.Add("@AttachDescription", SqlDbType.NVarChar);
                        command.Parameters.Add("@AttachTime", SqlDbType.DateTime); 
                        command.Parameters.Add("@AttachSize", SqlDbType.Int);
                        command.Parameters.Add("@ItemTypeID", SqlDbType.Int);
                        command.Parameters.Add("@ItemID", SqlDbType.Int);
                        command.Parameters.Add("@UserID", SqlDbType.Int);
                        command.Parameters.Add("@AttachData", SqlDbType.Image);
                        command.Parameters.Add("@MyCreatorName", SqlDbType.NVarChar);
                        command.Parameters.Add("@ContentType", SqlDbType.NVarChar);
                        connection.Open();
                        //     for (int t = 0; t < row.ItemArray.Count()-2; t++)

                        for (int t = mone; t < (mone + 3); t++)
                        {
                            //  SET the values
                            try
                            {
                                command.Parameters["@AttachSize"].Value = int.Parse((dt.Rows[t][4]).ToString());
                                command.Parameters["@ItemTypeID"].Value = int.Parse((dt.Rows[t][9]).ToString());
                            }
                            catch //if ReqNo or LineId are empty do not insert the line
                            {
                                continue;
                            }
                            command.Parameters["@ItemID"].Value = int.Parse((dt.Rows[t][0]).ToString());
                            command.Parameters["@AttachName"].Value = (dt.Rows[t][1]).ToString();
                            command.Parameters["@AttachDescription"].Value = (dt.Rows[t][2]).ToString();
                            command.Parameters["@AttachTime"].Value = DateTime.Parse((dt.Rows[t][3]).ToString());
                            //command.Parameters["@AttachSize"].Value = int.Parse((dt.Rows[t][4]).ToString());
                            command.Parameters["@MyCreatorName"].Value = (dt.Rows[t][5]).ToString();
                            command.Parameters["@ContentType"].Value = (dt.Rows[t][6]).ToString();
                            command.Parameters["@AttachData"].Value = Convert.FromBase64String((dt.Rows[t][7]).ToString());
                            command.Parameters["@UserID"].Value = int.Parse((dt.Rows[t][8]).ToString());
                            //command.Parameters["@RejectRsn"].Value = (dt.Rows[t][5]).ToString();
                            /*try
                            {
                                command.Parameters["@BillTo"].Value = int.Parse((dt.Rows[t][6]).ToString());
                            }
                            catch
                            {
                                command.Parameters["@BillTo"].Value = 0;
                            }*/
                            //command.Parameters["@InternalNotes"].Value = (dt.Rows[t][7]).ToString();
                            command.ExecuteNonQuery();
                        }
                        connection.Close();
                    }
                    mone = mone + 3;
                }
            //if (count > 0)

                //יש פחות שורות מ3 ולכן ישלחו אחת אחרי השניה

                //AddIntoPsAttachments(dt, count);
        }

        public static void insertComments(DataTable dt)
        {
            int id;
            int i, count = dt.Rows.Count;
            int NumOfRow = dt.Rows.Count;
            //פרמטרים של טבלת תגובות
            int MyTaskID, MyCreatorID , Comment_ID;
            string MyActivityDesc, MyCreatorName;
            DateTime MyCreateTime, MyActivityTime;
            
            i = count - NumOfRow;
            count = NumOfRow;
            while (dt.Rows.Count > 0 && count > 0)
            {
                count--;
                DataRow row = dt.Rows[i++];
                Comment_ID = int.Parse(row[6].ToString());
                MyTaskID = int.Parse(row[0].ToString());
                MyCreatorID = int.Parse(row[4].ToString());
                MyActivityDesc = row[2].ToString();
                MyCreatorName = row[3].ToString();
                MyCreateTime = DateTime.Parse(row[1].ToString());
                MyActivityTime = DateTime.Parse(row[5].ToString());

                //string insertQuery = "INSERT INTO tblTaskActivity (TaskID,CreateTime,ActivityDescription, CreatorName, CreatorID, ActivityTime, Salessoft_id) VALUES (@MyTaskID, @MyCreateTime, @MyActivityDesc, @MyCreatorName, @MyCreatorID, @MyActivityTime, @Comment_ID) \n\r";
                string insertQuery = " IF NOT EXISTS (select * from tblTaskActivity where (salessoft_id = @Comment_ID)) \n\r" +
              " BEGIN \n\r" +
              "     INSERT INTO tblTaskActivity (TaskID,CreateTime,ActivityDescription, CreatorName, CreatorID, ActivityTime, salessoft_id) VALUES (@MyTaskID, @MyCreateTime, @MyActivityDesc, @MyCreatorName, @MyCreatorID, @MyActivityTime, @Comment_ID); \n\r" +
              " END ";
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after comment id" + Comment_ID+  Environment.NewLine);
                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                    {
                        try
                        {
                            //cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@MyTaskID", SqlDbType.Int).Value = MyTaskID;
                            cmd.Parameters.Add("@MyCreatorID", SqlDbType.Int).Value = MyCreatorID;
                            cmd.Parameters.Add("@MyActivityDesc", SqlDbType.NVarChar).Value = MyActivityDesc;
                            cmd.Parameters.Add("@MyCreatorName", SqlDbType.NVarChar).Value = MyCreatorName;
                            cmd.Parameters.Add("@MyCreateTime", SqlDbType.DateTime).Value = MyCreateTime;
                            cmd.Parameters.Add("@MyActivityTime", SqlDbType.DateTime).Value = MyActivityTime;
                            cmd.Parameters.Add("@Comment_ID", SqlDbType.Int).Value = Comment_ID;
                        }
                        catch (Exception e)
                        {
                            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "FAIL put values into comments table" + e + Environment.NewLine);
                            //EventManager.WriteEventErrorMessage("failed to put values for CA_RequestLineDetails table", e);

                        }
                        try
                        {
                            con.Open();
                            //id = (Int32)cmd.ExecuteScalar(); 
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception e)
                        {
                            //File.AppendAllText(@"C:\Carmel\download.txt", "FAIL execute CA_RequestLineDetails table" + e + Environment.NewLine);
                            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "FAIL execute comments table" + e + Environment.NewLine);

                            //EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_RequestLineDetails table", e);
                            //File.AppendAllText(@"C:\Carmel\download.txt", "FAIL execute CA_RequestLineDetails table" + e + Environment.NewLine);
                        }
                        try
                        {
                            con.Close();
                            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "done comments table"  + Environment.NewLine);

                        }
                        catch (Exception e)
                        {
                            //File.AppendAllText(@"C:\Carmel\download.txt", "FAIL close CA_RequestLineDetails table" + e + Environment.NewLine);
                            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "FAIL close comments table" + e + Environment.NewLine);
                            //EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_RequestLineDetails table", e);
                            //File.AppendAllText(@"C:\Carmel\download.txt", "FAIL close CA_RequestLineDetails table" + e + Environment.NewLine);
                        }
                    }
                }


            }
        }

        public static void insertAttachments(DataTable dt)
        {
            int id;
            int i, count = dt.Rows.Count;
            int NumOfRow = dt.Rows.Count;
            //פרמטרים של טבלת תגובות
            int  AttachSize , ItemTypeID, ItemID , UserID , Attachment_ID;
            string AttachName, AttachDescription, MyCreatorName, ContentType , AttachData;
            DateTime AttachTime;
            Image data;

            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "start while attachments" + Environment.NewLine);
            i = count - NumOfRow;
            count = NumOfRow;
            while (dt.Rows.Count > 0 && count > 0)
            {
                count--;
                DataRow row = dt.Rows[i++];
                ItemID = int.Parse(row[0].ToString());
                AttachName = row[1].ToString();
                AttachDescription = row[2].ToString();
                AttachTime = DateTime.Parse(row[3].ToString());
                AttachSize = int.Parse(row[4].ToString());
                MyCreatorName = row[5].ToString();
                ContentType = row[6].ToString();
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "before bytes attach" + Environment.NewLine);
                byte[] imageBytes = new byte[row[7].ToString().Length];
                try
                {
                    imageBytes = Convert.FromBase64String(row[7].ToString());
                }
                catch (Exception e)
                {
                    File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "catch byte convert" + e + Environment.NewLine);
                }             
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after bytes attach" + Environment.NewLine);
                string hex = BitConverter.ToString(imageBytes);
                hex = hex.Replace("-", "");
                hex = "0x" + hex;
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after hex attach" + Environment.NewLine);
                /*using (var ms = new MemoryStream(imageBytes, 0, imageBytes.Length))
                {
                    data = Image.FromStream(ms, true);
                }*/          
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after data attach" + Environment.NewLine);
                //AttachData = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(row[7].ToString()));
                UserID = int.Parse(row[8].ToString());
                ItemTypeID = int.Parse(row[9].ToString());
                Attachment_ID  = int.Parse(row[10].ToString());
                //string insertQuery = "insert into tblAttach(AttachName, AttachDescription, AttachTime, AttachSize, ItemTypeID, ItemID, UserID, AttachData, CreatorName, ContentType , Salessoft_id) VALUES(@AttachName, @AttachDescription, @AttachTime, @AttachSize, @ItemTypeID, @ItemID, @UserID, @AttachData, @MyCreatorName, @ContentType ,@Attachment_ID ) \n\r";
                string insertQuery = " IF NOT EXISTS (select * from tblAttach where (Salessoft_id = @Attachment_ID)) \n\r" +
              " BEGIN \n\r" +
              "     insert into tblAttach(AttachName, AttachDescription, AttachTime, AttachSize, ItemTypeID, ItemID, UserID, AttachData, CreatorName, ContentType , Salessoft_id) VALUES(@AttachName, @AttachDescription, @AttachTime, @AttachSize, @ItemTypeID, @ItemID, @UserID, @AttachData, @MyCreatorName, @ContentType ,@Attachment_ID ); \n\r" +
              " END";
                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after string attach query" + Environment.NewLine);

                File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "after attach id" + Attachment_ID + Environment.NewLine);
                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                    {
                        try
                        {
                            //cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@ItemID", SqlDbType.Int).Value = ItemID;
                            cmd.Parameters.Add("@AttachName", SqlDbType.NVarChar).Value = AttachName;
                            cmd.Parameters.Add("@AttachDescription", SqlDbType.NVarChar).Value = AttachDescription;
                            cmd.Parameters.Add("@AttachTime", SqlDbType.DateTime).Value = AttachTime;
                            cmd.Parameters.Add("@AttachSize", SqlDbType.Int).Value = AttachSize;
                            cmd.Parameters.Add("@MyCreatorName", SqlDbType.NVarChar).Value = MyCreatorName;
                            cmd.Parameters.Add("@ContentType", SqlDbType.NVarChar).Value = ContentType;
                            cmd.Parameters.Add("@AttachData", SqlDbType.Image).Value = imageBytes;
                            cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
                            cmd.Parameters.Add("@ItemTypeID", SqlDbType.Int).Value = ItemTypeID;
                            cmd.Parameters.Add("@Attachment_ID", SqlDbType.Int).Value = Attachment_ID;
                        }
                        catch (Exception e)
                        {
                            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "FAIL put values into attachments table" + e + Environment.NewLine);
                            //EventManager.WriteEventErrorMessage("failed to put values for CA_RequestLineDetails table", e);

                        }
                        try
                        {
                            con.Open();
                            //id = (Int32)cmd.ExecuteScalar();
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception e)
                        {
                            //File.AppendAllText(@"C:\Carmel\download.txt", "FAIL execute CA_RequestLineDetails table" + e + Environment.NewLine);
                            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "FAIL execute attachments table" + e + Environment.NewLine);

                            //EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_RequestLineDetails table", e);
                            //File.AppendAllText(@"C:\Carmel\download.txt", "FAIL execute CA_RequestLineDetails table" + e + Environment.NewLine);
                        }
                        try
                        {
                            con.Close();
                            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "done attachments table" + Environment.NewLine);

                        }
                        catch (Exception e)
                        {
                            //File.AppendAllText(@"C:\Carmel\download.txt", "FAIL close CA_RequestLineDetails table" + e + Environment.NewLine);
                            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "FAIL close attachments table" + e + Environment.NewLine);
                            //EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_RequestLineDetails table", e);
                            //File.AppendAllText(@"C:\Carmel\download.txt", "FAIL close CA_RequestLineDetails table" + e + Environment.NewLine);
                        }
                    }
                }


            }
        }


        //  https://social.msdn.microsoft.com/Forums/vstudio/en-US/f14523f8-3a40-451b-983b-ae4f5fd12697/how-to-load-data-from-csv-file-in-temp-table-in-c?forum=csharpgeneral
        public void AddIntotblTaskActivity(DataTable dt)
        {
            // https://stackoverflow.com/questions/29046715/extract-values-from-datatable-with-single-row
            int i = 0, count = dt.Rows.Count;
            //פרמטרים של טבלת tblTaskActivity
            DateTime d = new DateTime(1753, 10, 10); //deafult
            int TaskID ,CreatorID, TaskStatusID;
            string  CreatorName;
            DateTime CreateTime, ActivityTime;

            while (dt.Rows.Count > 0 && count > 0)
            {
                count--;
                DataRow row = dt.Rows[i++];
                //זימון פונקציה שתבדוק עבור סוג בקשה אם קיים אם כן תעדכן תאור אחרת תוסיף לטבלה
                try //if there is no ReqNo do not insert the request
                {
                    TaskID = int.Parse(row[0].ToString());
                }
                catch
                {
                    continue;
                }
                try
                {
                    CreateTime = DateTime.Parse(row[1].ToString());
                }
                catch
                {
                    CreateTime = d;
                }

                CreatorName = row[2].ToString();
                try
                {
                    CreatorID = int.Parse(row[3].ToString());
                }
                catch
                {
                    continue;
                }

                try
                {
                    ActivityTime = DateTime.Parse(row[4].ToString());
                }
                catch
                {
                    ActivityTime = d;
                }
                try
                {
                    TaskStatusID = int.Parse(row[5].ToString());
                }
                catch
                {
                    TaskStatusID = 0;
                }

                //int CurrStatus = getCurrStatusiD(TaskStatusID);

                //update status and insert automatic comment:
                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("updateTaskStatus", con))
                    {
                        try
                        {
                            File.AppendAllText(@"C:\HashConnector\carmelService\download.txt", "start procedure AddIntotblTaskActivity" + Environment.NewLine);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@MyTaskID", SqlDbType.Int).Value = TaskID;
                            cmd.Parameters.Add("@MyCreateTime", SqlDbType.DateTime).Value = CreateTime;
                            //cmd.Parameters.Add("@MyActivityDesc", SqlDbType.NVarChar).Value = MyActivityDesc;
                            cmd.Parameters.Add("@MyCreatorName", SqlDbType.NVarChar).Value = CreatorName;
                            cmd.Parameters.Add("@MyCreatorID", SqlDbType.Int).Value = CreatorID;
                            cmd.Parameters.Add("@MyActivityTime", SqlDbType.DateTime).Value = ActivityTime;
                            cmd.Parameters.Add("@TaskStatusID", SqlDbType.Int).Value = TaskStatusID;

                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to put values for updateTaskStatus procedure", e);
                        }
                        try
                        {
                            con.Open();
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to open ConnectionString for updateTaskStatus procedure", e);
                        }
                        try
                        {

                            con.Close();
                            File.AppendAllText(@"C:\Carmel\download.txt", "done updateTaskStatus procedure" + Environment.NewLine);
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to close ConnectionString for updateTaskStatus procedure", e);
                        }
                    }
                }


                /*string insertTasks = "INSERT INTO tblTaskActivity (TaskID,CreateTime,ActivityDescription, CreatorName, CreatorID, ActivityTime) VALUES (@MyTaskID, @MyCreateTime, @MyActivityDesc, @MyCreatorName, @MyCreatorID, @MyActivityTime)";
                EventManager.WriteEventInfoMessage("start ConnectionString to db for tblTaskActivity table");

                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("insertTasks", con))
                    {
                        try
                        {
                            //cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@MyTaskID", SqlDbType.Int).Value = MyTaskID;
                            cmd.Parameters.Add("@MyCreateTime", SqlDbType.DateTime).Value = MyCreateTime;
                            cmd.Parameters.Add("@MyActivityDesc", SqlDbType.NVarChar).Value = MyActivityDesc;
                            cmd.Parameters.Add("@MyCreatorName", SqlDbType.NVarChar).Value = MyCreatorName;
                            cmd.Parameters.Add("@MyCreatorID", SqlDbType.Int).Value = MyCreatorID;
                            cmd.Parameters.Add("@MyActivityTime", SqlDbType.DateTime).Value = MyActivityTime;
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to put values for tblTaskActivity table", e);
                        }
                        try
                        {
                            con.Open();
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to open ConnectionString for tblTaskActivity table", e);
                        }
                        try
                        {
                       
                            con.Close();
                            File.AppendAllText(@"C:\Carmel\download.txt", "done AddIntotblTaskActivity" + Environment.NewLine);
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to close ConnectionString for tblTaskActivity table", e);
                        }
                    }
                }*/




            }
        }

        public static int getCurrStatusiD(int status)
        {
            int result = 0;
            string sql = "Select TaskStatusid From tblTask where Taskid=" + status;
            using (SqlConnection conn = new SqlConnection(m_ConnectionString))
            {
                //conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    try
                    {
                        conn.Open();
                        result = (Int32)cmd.ExecuteScalar();
                    }
                    catch (Exception e)
                    {
                        EventManager.WriteEventErrorMessage("failed to open ConnectionString for tblTask table", e);
                    }
                    try
                    {

                        conn.Close();
                        File.AppendAllText(@"C:\Carmel\download.txt", "done tblTask" + Environment.NewLine);
                    }
                    catch (Exception e)
                    {
                        EventManager.WriteEventErrorMessage("failed to close ConnectionString for tblTask table", e);
                    }
                    //result = (Int32)cmd.ExecuteScalar();
                }

            }
            return result;
        }


        public static void AddIntoPsFiles(DataTable dt)
        {
            int i = 0, count = dt.Rows.Count;
            //פרמטרים של טבלת CA_Files
            int ReqNo, LineId;
            string Descrptn, FileLink, FileName, AddTime;
            DateTime AddDate;
            //  DateTime AddDate, AddTime;
            while (dt.Rows.Count > 0 && count > 0)
            {

                count--;
                DataRow row = dt.Rows[i++];
                if (row[6].ToString() != "")
                {
                    ReqNo = int.Parse(row[0].ToString());
                    LineId = int.Parse(row[1].ToString());
                    Descrptn = row[2].ToString();
                    FileLink = row[3].ToString();
                    FileName = row[4].ToString();
                    AddDate = DateTime.Parse(row[5].ToString());
                    AddTime = row[6].ToString();

                    using (SqlConnection con = new SqlConnection(m_ConnectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("Files_temp", con))
                        {
                            try
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                                cmd.Parameters.Add("@LineId", SqlDbType.Int).Value = LineId;
                                cmd.Parameters.Add("@Descrptn", SqlDbType.NVarChar).Value = Descrptn;
                                cmd.Parameters.Add("@FileLink", SqlDbType.NVarChar).Value = FileLink;
                                cmd.Parameters.Add("@FileName", SqlDbType.NVarChar).Value = FileName;
                                cmd.Parameters.Add("@AddDate", SqlDbType.DateTime).Value = AddDate;
                                cmd.Parameters.Add("@AddTime", SqlDbType.NVarChar).Value = AddTime;
                            }
                            catch (Exception e)
                            {
                                EventManager.WriteEventErrorMessage("failed to put values for CA_Files table", e);
                            }
                            try
                            {
                                con.Open();
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception e)
                            {
                                EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_Files table", e);
                            }
                            try
                            {
                                con.Close();
                            }
                            catch (Exception e)
                            {
                                EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_Files table", e);
                            }
                        }
                    }
                }
            }
        }
        //פונקציה שמבצעת התחברות ל
        //URL
        // עם יוזר וסיסמא
        public String getData(string uid, string pwd, string url)
        {
            // Create a request using a URL that can receive a post. 
            request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.CookieContainer = cookieContainer;
            //added by liat in case customer has proxy 25/04/2016  
            IWebProxy wp = WebRequest.DefaultWebProxy;
            wp.Credentials = CredentialCache.DefaultCredentials;
            request.Proxy = wp;
            //end Change
            // Set the Method property of the request to POST.
            request.Method = "POST";

            // Set the ContentType property of the WebRequest.
            request.ContentType = "application/x-www-form-urlencoded";

            // Create POST data and convert it to a byte array.
            string postData = "email=" + uid + "&password=" + pwd;
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);

            // Set the ContentLength property of the WebRequest.
            request.ContentLength = byteArray.Length;
            request.KeepAlive = true;

            // Get the request stream.
            using (Stream dataStream = request.GetRequestStream())
            {
                dataStream.Write(byteArray, 0, byteArray.Length);
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);
                String resptext = "";
                using (Stream stream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(stream, Encoding.UTF8);
                    resptext = reader.ReadToEnd();
                }


                response.Close();
                return resptext;
            }
            catch (WebException we)
            {

            }
            catch (Exception we)
            {
            }
            //HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            //response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);
            //response.Close();
            return "";

        }

        public void uploadfile(string filePath, string specificUrl)
        {
            string url = m_url + specificUrl;//@"importcustomercards/exportcustomercards/importcsv";
            Console.WriteLine(url);
            //Identificate separator
            string boundary = "---------------------------" + DateTime.Now.Ticks.ToString("x");
            //Encoding
            byte[] boundarybytes = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "\r\n");

            //Creation and specification of the request
            HttpWebRequest wr = (HttpWebRequest)WebRequest.Create(url); //sVal is id for the webService
            wr.CookieContainer = cookieContainer;
            wr.ContentType = "multipart/form-data; boundary=" + boundary;
            wr.Method = "POST";
            wr.KeepAlive = true;
            wr.Credentials = System.Net.CredentialCache.DefaultCredentials;


            Stream rs = wr.GetRequestStream();
            byte[] authBytes = System.Text.Encoding.UTF8.GetBytes(string.Format("Content-Disposition: form-data; name=\"{0}\";\r\n\r\n{1}", "email", this.email));
            rs.Write(boundarybytes, 0, boundarybytes.Length);
            rs.Write(authBytes, 0, authBytes.Length);
            rs.Write(boundarybytes, 0, boundarybytes.Length);

            authBytes = System.Text.Encoding.UTF8.GetBytes(string.Format("Content-Disposition: form-data; name=\"{0}\";\r\n\r\n{1}", "password", this.password));
            rs.Write(boundarybytes, 0, boundarybytes.Length);
            rs.Write(authBytes, 0, authBytes.Length);
            rs.Write(boundarybytes, 0, boundarybytes.Length);

            //,this.pwd

            rs.Write(boundarybytes, 0, boundarybytes.Length);
            byte[] formitembytes = System.Text.Encoding.UTF8.GetBytes(filePath);
            rs.Write(formitembytes, 0, formitembytes.Length);

            rs.Write(boundarybytes, 0, boundarybytes.Length);

            string headerTemplate = "Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n";
            string f = filePath;
            string check = f.Substring(f.Length - 3);
            string header;
            if (check.Equals("xml"))
            {
                header = string.Format(headerTemplate, "file", "AAAAAAA.xml", wr.ContentType);
            }
            else
            {
                header = string.Format(headerTemplate, "file", "AAAAAAA.csv", wr.ContentType);
            }
            //string header = string.Format(headerTemplate, "file", "AAAAAAA.csv", wr.ContentType);
            byte[] headerbytes = System.Text.Encoding.UTF8.GetBytes(header);
            rs.Write(headerbytes, 0, headerbytes.Length);

            FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            byte[] buffer = new byte[4096];
            int bytesRead = 0;
            while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0)
            {
                rs.Write(buffer, 0, bytesRead);
            }
            fileStream.Close();

            byte[] trailer = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "--\r\n");
            rs.Write(trailer, 0, trailer.Length);
            rs.Close();
            rs = null;

            WebResponse wresp = null;
            try
            {
                //Get the response
                wresp = wr.GetResponse();
                Stream stream2 = wresp.GetResponseStream();
                StreamReader reader2 = new StreamReader(stream2);
                string responseData = reader2.ReadToEnd();
                //EventManager.WriteEventInfoMessage("response is:\n" + responseData);

            }
            catch (Exception ex)
            {
                string s = ex.Message;
            }
            finally
            {
                if (wresp != null)
                {
                    wresp.Close();
                    wresp = null;
                }
                wr = null;
            }



        }

        public void handleIDS(string specificUrl)
        {
            try
            {
                string file = "";
                File.AppendAllText(@"C:\orly\logUpload.txt", "in try procedure" + Environment.NewLine);
                toXml("ids");
                file = @"C:\Carmel\sapNum.xml";              
                try
                {
                    //EventManager.WriteEventInfoMessage("try do login");
                    doLogin(m_user, m_pass, m_url);

                    //if success do login
                    try
                    {
                        //EventManager.WriteEventInfoMessage("try upload file");
                        uploadfile(file, specificUrl);
                        //EventManager.WriteEventInfoMessage("finish upload file");
                    }
                    catch (Exception ex)
                    {
                        EventManager.WriteEventInfoMessage("cath upload file");
                    }
                    try
                    {
                        //EventManager.WriteEventInfoMessage("try do logout");
                        doLogout(m_url);
                    }
                    catch (Exception ex)
                    {
                        EventManager.WriteEventInfoMessage("cath do loout");
                    }


                }
                catch (Exception ex)
                {
                    EventManager.WriteEventErrorMessage("catch login", ex);
                }

            }
            catch (Exception ex)
            {
                EventManager.WriteEventErrorMessage("Error while reading procedur from China", ex);

            }

        }

        public void toXml(string commandName)
        {
            string connStr = @"" + m_ConnectionString;//.Substring(pos, m_ConnectionString.Length -pos - 1 );
            SqlConnection connection;
            SqlDataAdapter adapter;
            SqlCommand command = new SqlCommand();
            connection = null;
            connection = new SqlConnection(connStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand(commandName, connection);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add(new SqlParameter("@CustomerID", custId));

            //System.Xml.XmlReader myXmlReader = cmd.ExecuteXmlReader();
            //System.Xml.XmlReader myXmlReader = cmd.ExecuteXmlReader();
            using (XmlReader reader = cmd.ExecuteXmlReader())
            {
                XmlDocument dom = new XmlDocument();
                dom.CreateXmlDeclaration("1.0", "UTF-8", null);

                dom.Load(reader);
                //dom.Declaration = new XDeclaration("1.0", "utf-8", null);

                var settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;
                settings.Encoding = Encoding.UTF8;

                using (var writer = XmlTextWriter.Create(@"C:\temp\Hash\ids.xml", settings))
                {
                    dom.WriteContentTo(writer);
                }

                //reader.close();
            }
            //reader.close();
            //myXmlReader.Close();
            //return myXmlReader;
            connection.Close();
        }


        public bool doLogin(string uid, string pwd, string url)
        {
            // Create a request using a URL that can receive a post. 
            request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.CookieContainer = cookieContainer;
            //added by liat in case customer has proxy 25/04/2016  
            IWebProxy wp = WebRequest.DefaultWebProxy;
            wp.Credentials = CredentialCache.DefaultCredentials;
            request.Proxy = wp;
            //end Change
            // Set the Method property of the request to POST.
            request.Method = "POST";

            // Set the ContentType property of the WebRequest.
            request.ContentType = "application/x-www-form-urlencoded";

            // Create POST data and convert it to a byte array.
            string postData = "email=" + uid + "&password=" + pwd;
            this.email = uid;
            this.password = pwd;
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);

            // Set the ContentLength property of the WebRequest.
            request.ContentLength = byteArray.Length;
            request.KeepAlive = true;

            // Get the request stream.
            using (Stream dataStream = request.GetRequestStream())
            {
                dataStream.Write(byteArray, 0, byteArray.Length);
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                foreach (Cookie cook in response.Cookies)
                    cookieContainer.Add(cook);

                response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);

                response.Close();
            }
            catch (WebException we)
            {
            }
            catch (Exception we)
            {
            }
            //HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            //response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);
            //response.Close();
            return true;

        }

        public void doLogout(string url)
        {
            // Create a request using a URL that can receive a post. 
            request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.CookieContainer = cookieContainer;

            // Set the Method property of the request to POST.
            request.Method = "GET";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            response.Close();
        }

    }
}

